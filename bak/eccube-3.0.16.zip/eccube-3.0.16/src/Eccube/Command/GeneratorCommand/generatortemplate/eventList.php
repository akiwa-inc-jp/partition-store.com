<?php

return array(
    'eccube.event.app.before' => 'AppBefore',
    'eccube.event.app.after' => 'AppAfter',
);
