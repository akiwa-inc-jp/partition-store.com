<?php

return array(
    'eccube.event.app.request' => 'AppRequest',
    'eccube.event.app.controller' => 'AppController',
    'eccube.event.app.response' => 'AppResponse',
    'eccube.event.app.exception' => 'AppException',
    'eccube.event.app.terminate' => 'AppTerminate',
    'eccube.event.front.request' => 'FrontRequest',
    'eccube.event.front.controller' => 'FrontController',
    'eccube.event.front.response' => 'FrontResponse',
    'eccube.event.front.exception' => 'FrontException',
    'eccube.event.front.terminate' => 'FrontTerminate',
    'eccube.event.admin.request' => 'AdminRequest',
    'eccube.event.admin.controller' => 'AdminController',
    'eccube.event.admin.response' => 'AdminResponse',
    'eccube.event.admin.exception' => 'AdminException',
    'eccube.event.admin.terminate' => 'AdminTerminate',
);
